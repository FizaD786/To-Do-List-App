package com.example.madproject_todolist;

import android.os.Parcel;
import android.os.Parcelable;

public class Task implements Parcelable {
    public static final int PRIORITY_LOW = 0;
    public static final int PRIORITY_MEDIUM = 1;
    public static final int PRIORITY_HIGH = 2;

    private String name;
    private int priority;
    private String dueDate;
    private String time;

    public Task(String name, int priority, String dueDate, String time) {
        this.name = name;
        this.priority = priority;
        this.dueDate = dueDate;
        this.time = time;
    }

    protected Task(Parcel in) {
        name = in.readString();
        priority = in.readInt();
        dueDate = in.readString();
        time = in.readString();
    }

    public static final Creator<Task> CREATOR = new Creator<Task>() {
        @Override
        public Task createFromParcel(Parcel in) {
            return new Task(in);
        }

        @Override
        public Task[] newArray(int size) {
            return new Task[size];
        }
    };

    public String getName() {
        return name;
    }

    public int getPriority() {
        return priority;
    }

    public String getDueDate() {
        return dueDate;
    }

    public String getTime() {
        return time;
    }

    public boolean isHeader() {
        return name.isEmpty();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeInt(priority);
        dest.writeString(dueDate);
        dest.writeString(time);
    }
}
